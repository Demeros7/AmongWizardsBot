import os
token = os.environ.get("DISCORD_TOKEN")
print(f"Token: {token}")
print("Variáveis de ambiente:", list(os.environ.keys()))